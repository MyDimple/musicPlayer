import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import QtQml
import "freems.js" as Control
RowLayout{
    spacing: 0

    property int defaultIndex: 0

    property var qmlList: [
        {icon:"qrc:/icons/tuijianbaobiao.png",value:"推荐内容",qml:"DetailRecommendPageView",menu:true},
        {icon:"qrc:/icons/sousuo_1.png",value:"搜索音乐",qml:"DetailSearchPageView",menu:true},
        {icon:"qrc:/icons/bendi.png",value:"本地音乐",qml:"DetailLocalPageView",menu:true},
        {icon:"qrc:/icons/lishi.png",value:"播放历史",qml:"DetailHistoryPageView",menu:true},
        {icon:"qrc:/icons/xihuan.png",value:"我喜欢的",qml:"DetailFavoritePageView",menu:true},
        {icon:"",value:"",qml:"DetailPlayListPageView",menu:false},

    ]

//左边菜单
Frame{
    Layout.preferredWidth: 200
    Layout.fillHeight: true
    background: Rectangle{//菜单栏背景
        // color: "#1000AAAA"
        color:"#ffffff"
    }

    padding: 0

    ColumnLayout{
        anchors.fill: parent
        //占位item
        Item{
            Layout.fillWidth: true
            Layout.preferredHeight: 150
            //中间左上方自定义图片
            MusicBorderImage{
                anchors.centerIn:parent
                height: 100
                width:100
                borderRadius: 100
            }
        }

        //菜单栏
        ListView{
            id:menuView
            height: parent.height
            Layout.fillHeight: true
            Layout.fillWidth: true
            spacing: 5
            model:ListModel{
                id:menuViewModel
            }
            delegate:menuViewDelegate
            highlight: Rectangle{//点击后的高亮效果
                // color: "#5073a7ab"
                color: "#bdbdbd"
                radius: 10
            }
            highlightMoveDuration: 100
        }
    }

    Component{
        id:menuViewDelegate
        Rectangle{
            id:menuViewDelegateItem
            height: 56
            width: 200
            color: mouse.hovered?"#eaeaea":"#15ffffff" //左边菜单默认颜色
            radius: 10
            border.width: 1
            border.color: "black"
            RowLayout{
                anchors.fill: parent
                anchors.centerIn: parent
                spacing:15
                Item{
                    width: 30
                }

                Image{
                    source: icon
                    Layout.preferredHeight: 20
                    Layout.preferredWidth: 20
                }

                Text{
                    text:value
                    Layout.fillWidth: true
                    height:50
                    font.family:"微软雅黑"
                    font.pointSize: 12
                    // color: "#ffffff"

                }
            }

            HoverHandler{
                id:mouse
                acceptedDevices: PointerDevice.Mouse | PointerDevice.TouchPad
                cursorShape: Qt.PointingHandCursor
                // cursorShape: Qt.PointingHandCursor
            }

            TapHandler{
                onTapped: {
                    Control.hidePlayList()
                    repeater.itemAt(menuViewDelegateItem.ListView.view.currentIndex).visible = false //将原本索引的内容不可视
                    menuViewDelegateItem.ListView.view.currentIndex = index //设置当前索引
                    var loader = repeater.itemAt(index) //获取当前索引的loader
                    loader.visible = true //让其可视
                    loader.source = qmlList[index].qml + ".qml"
                }
            }



        }
    }

    Component.onCompleted: {
        menuViewModel.append(qmlList.filter(item=>item.menu)) //增加过滤器，隐藏歌单不在左边菜单栏显示

        //加载完成后的默认页面
        var loader = repeater.itemAt(defaultIndex) //获取第一个loader
        loader.visible = true //让其可视
        loader.source = qmlList[defaultIndex].qml + ".qml"

        menuView.currentIndex=defaultIndex
    }
}

    Repeater{//重复构造子组件
        id:repeater
        model: qmlList.length
        Loader{//加载页面
            visible:false //默认都不显示
            Layout.fillHeight: true
            Layout.fillWidth: true

        }
    }



}
