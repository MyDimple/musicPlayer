import QtQuick 2.15
import QtQuick.Controls
import QtQuick.Layouts
import QtQuick.Shapes
import "freems.js" as Control
Frame{
    property bool deletable: true
    property bool favoritable: true
    signal deleteItem(int index)
    property var musiclist: []
    property alias lsModel: listViewModel
    property int all: 0
    property int pageSize: 60
    property int current: 0
    signal loadMore(int offset,int current) //加载其他页的信号
    Layout.fillHeight: true
    Layout.fillWidth: true
    clip:true
    spacing: 0
    padding: 0
    onMusiclistChanged: {
        // musiclist.length
        listViewModel.clear()
        listViewModel.append(musiclist)
    }
    background: Rectangle{
        color:"#e6e6e6"
    }

    ListView{
        anchors.bottomMargin: 70
        id:listView
        anchors.fill: parent
        model:ListModel{
            id:listViewModel
        }
        delegate: listViewDelegate
        ScrollBar.vertical: ScrollBar{
            anchors.right: parent.right
        }
        header: listViewHeader
        highlight: Rectangle{
            color:"#00000000"
        }
        highlightMoveDuration: 0
        highlightResizeDuration: 0
    }
    Component{
        id:listViewDelegate
        Rectangle{
             color: mouse.hovered ? "#d1d1d1" : "#00000000"

            height:45
            width: listView.width

            Shape{
                Component.onCompleted: {
                        // 在这里可以安全地访问parent.width，因为此时组件已经完成初始化
                        pathline2.x = parent.width
                    }
                anchors.fill: parent
                ShapePath{
                    strokeWidth: 0
                    strokeColor: "#50000000"
                    strokeStyle: ShapePath.SolidLine
                    startX: 0
                    startY: 45
                    PathLine{
                        x:0
                        y:45
                    }
                    PathLine{
                        id:pathline2
                        x:0
                        y:45
                    }
                }
            }
            RowLayout{
                id:item
                TapHandler{
                    onTapped: listView.currentIndex=index
                }
                //取代了MouseArea的作用
                HoverHandler {
                    id: mouse
                    acceptedDevices: PointerDevice.Mouse | PointerDevice.TouchPad
                    cursorShape: Qt.PointingHandCursor
                }

                width: parent.width
                height: parent.height
                spacing: 15
                x:5
                Text{
                    text:index+1+pageSize*current//解决其他分页的序号相同的问题
                    horizontalAlignment: Qt.AlignHCenter
                    Layout.preferredWidth: parent.width*0.05
                    font.family: "微软雅黑"
                    font.pointSize: 13
                    color:"#4d4c4c"
                    elide:Qt.ElideRight//截断
                }
                Text{
                    text:name
                    Layout.preferredWidth: parent.width*0.4
                    font.family: "微软雅黑"
                    font.pointSize: 13
                    color:"#4d4c4c"
                    elide:Qt.ElideRight//截断
                }
                Text{
                    text:artist
                    horizontalAlignment: Qt.AlignHCenter
                    Layout.preferredWidth: parent.width*0.15
                    font.family: "微软雅黑"
                    font.pointSize: 13
                    color:"#4d4c4c"
                    elide:Qt.ElideMiddle//截断
                }
                Text{
                    text:album
                    horizontalAlignment: Qt.AlignHCenter
                    Layout.preferredWidth: parent.width*0.15
                    font.family: "微软雅黑"
                    font.pointSize: 13
                    color:"#4d4c4c"
                    elide:Qt.ElideMiddle//截断
                }
                Item{
                    Layout.preferredWidth: parent.width*0.15
                    RowLayout{
                        anchors.centerIn: parent
                        MusicIconButton{
                            iconSource: "qrc:/icons/bofang.png"
                            iconHeight: 16
                            iconWidth: 16
                            toolTip: "播放"
                            onClicked: {
                                layoutBottomView.current=-1
                                layoutBottomView.playList=musiclist
                                layoutBottomView.current=index
                            }
                        }
                        MusicIconButton{
                            iconSource: "qrc:/icons/xihuan_1.png"
                            visible: favoritable
                            iconHeight: 16
                            iconWidth: 16
                            toolTip: "喜欢"
                            onClicked: {
                                Control.saveFavorite({
                                                                  id:musiclist[index].id + "",
                                                                  name:musiclist[index].name,
                                                                  artist:musiclist[index].artist,
                                                                  url:musiclist[index].url?musiclist[index].url:"",
                                                                  type:musiclist[index].type?musiclist[index].type:"",
                                                                  album:musiclist[index].album?musiclist[index].album:"本地音乐"
                                                              })
                            }
                        }
                        MusicIconButton{
                            iconSource: "qrc:/icons/guanbi.png"
                            visible: deletable
                            iconHeight: 16
                            iconWidth: 16
                            toolTip: "删除"
                            onClicked: {
                                deleteItem(index)
                            }
                        }
                    }
                }

            }
        }
}
    Component{
        id:listViewHeader
        Rectangle{
            // color:"#5073a7ab"
            border.color: "black"
            border.width: 1
            // radius: 10
            height:45
            width: listView.width
            RowLayout{
                width: parent.width
                height: parent.height
                spacing: 15
                x:5
                Text{
                    text:"序号"
                    horizontalAlignment: Qt.AlignHCenter
                    Layout.preferredWidth: parent.width*0.05
                    font.family: "微软雅黑"
                    font.pointSize: 13
                    color:"black"
                    elide:Qt.ElideRight//截断
                }
                Text{
                    text:"歌名"
                    Layout.preferredWidth: parent.width*0.4
                    font.family: "微软雅黑"
                    font.pointSize: 13
                    color:"black"
                    elide:Qt.ElideRight//截断
                }
                Text{
                    text:"歌手"
                    horizontalAlignment: Qt.AlignHCenter
                    Layout.preferredWidth: parent.width*0.15
                    font.family: "微软雅黑"
                    font.pointSize: 13
                    color:"black"
                    elide:Qt.ElideMiddle//截断
                }
                Text{
                    text:"专辑"
                    horizontalAlignment: Qt.AlignHCenter
                    Layout.preferredWidth: parent.width*0.15
                    font.family: "微软雅黑"
                    font.pointSize: 13
                    color:"black"
                    elide:Qt.ElideMiddle//截断
                }
                Text{
                    text:"操作"
                    horizontalAlignment: Qt.AlignHCenter
                    Layout.preferredWidth: parent.width*0.15
                    font.family: "微软雅黑"
                    font.pointSize: 13
                    color:"black"
                    elide:Qt.ElideRight//截断
                }
            }
        }
    }

    //分页
    Item{
        id:pageButton
        visible: musiclist.length!==0
        width: parent.width
        height: 40
        anchors.top:listView.bottom
        anchors.topMargin: 20
        ButtonGroup{//该组件的作用，比如一堆按钮只能选中一个
            buttons:buttons.children
        }
        RowLayout{
            id:buttons
            anchors.centerIn: parent
            Repeater{

                id:repeater
                model:all/pageSize>9?9:all/pageSize
                Button{
                    Text{
                        anchors.centerIn: parent
                        text:modelData+1//索引
                        font.family:"微软雅黑"
                        font.pointSize: 14
                        color: checked?"#497563":"grey"
                    }
                    background: Rectangle{
                        implicitHeight: 30
                        implicitWidth: 30
                        color: checked?"#e2f0f8":"#20e9f4ff"
                        radius: 3
                    }
                    checkable: true
                    checked: modelData===current
                    onClicked: {
                        if(current===index)
                        {
                            return
                        }
                        current=index
                        loadMore(current*pageSize,index)
                    }
                }
            }
        }
    }
}
