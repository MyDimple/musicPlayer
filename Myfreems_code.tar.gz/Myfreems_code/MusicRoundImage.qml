import QtQuick 2.12
import QtQuick.Controls 2.5
import Qt5Compat.GraphicalEffects


Rectangle {
    property string imgSrc: "qrc:/icons/tingquanmao.png"
    property int borderRadius: 5
    // color: "#e6e6e6"
    Image{
        id:image
        anchors.centerIn: parent
        source:imgSrc
        smooth: true
        visible: false
        width: parent.width
        height: parent.height
        fillMode: Image.PreserveAspectCrop
        antialiasing: true
    }

    Rectangle{
        id:mask
        color: "black"
        anchors.fill: parent
        radius: borderRadius
        visible: false
        smooth: true
        antialiasing: true
    }

    OpacityMask{
        anchors.fill:image
        source: image
        maskSource: mask
        visible: true
        antialiasing: true
    }
}
